SELECT        DNI, Nombre, Apellido1, Apellido2, Direcc1, Direcc2, Ciudad, Provincia, Cod_Postal, Sexo,
              Fecha_Nac, Valoracion
FROM            Empleados
WHERE        (SUBSTRING(Nombre, 1, 2) = 'S�') OR
                         (SUBSTRING(Ciudad, 1, 1) = 'S')
SELECT        Cod_Espectaculo, Nombre, Tipo, Fecha_Inicial, Fecha_Final, Interprete, Cod_Recinto
FROM            Espectaculos
WHERE        (MONTH(Fecha_Inicial) = 3) AND (YEAR(Fecha_Inicial) > YEAR(GETDATE()) - 3)

SELECT      CodArticulo, Nombre, Precio, ROUND(Precio * 1.1, 2) AS NuevoPrecio, CodFabricante
FROM            Articulos

SELECT        CONCAT(Apellido1, Apellido2, Nombre) AS Patrimonio, SUBSTRING(Cod_Postal,1,2) AS Provincia
FROM            Empleados
SELECT        DNI, Nombre, Apellido1, Apellido2, Direcc1, Direcc2, Ciudad, Provincia, Cod_Postal, Sexo,
              Fecha_Nac, Valoracion
FROM            Empleados
WHERE        (CHARINDEX('del', Ciudad, 1) > 0)

SELECT        DNI, Nombre, Apellido1, Apellido2, Direcc1, Direcc2, Ciudad, Provincia, Cod_Postal, Sexo, Fecha_Nac, Valoracion
FROM            Empleados
WHERE     CAST(Cod_Postal as int) BETWEEN 28000 AND 28999

SELECT        Nombre + ' C/' + REPLACE(Direccion, 'calle', '') + ' ' + Ciudad AS Expr1
FROM            Espectadores

SELECT DATEDIFF(year, GETDATE(), '1989-11-23') AS diferenciaA�os,
	DATEDIFF(MONTH, GETDATE(), '1989-11-23') AS diferenciaMeses,
	DATEDIFF(WEEK, GETDATE(), '1989-11-23') AS diferenciaSemanas,
	DATEDIFF(DAY, GETDATE(), '1989-11-23') AS diferenciaDias

SELECT RAND(3) AS 'Random', LEN(CAST(RAND(3) as varchar)) AS LONGITUDclave