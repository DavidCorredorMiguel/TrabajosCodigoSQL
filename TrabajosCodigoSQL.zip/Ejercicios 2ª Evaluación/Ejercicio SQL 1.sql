CREATE TABLE PUB(
Cod_Pub INT IDENTITY (1,1) NOT NULL,
Nombre Varchar(50) NOT NULL,
Licencia_Fiscal varchar(50) NOT NULL,
Domicilio varchar(50) NULL,
Fecha_Apertura DATE NOT NULL,
Horario varchar(4)NOT NULL,
Cod_Localidad INT NOT NULL
)
CREATE TABLE Existencias(
Cod_Articlo INT IDENTITY (1,1) NOT NULL,
Nombre Varchar(50) NOT NULL,
Cantidad INT NOT NULL,
Precio Float NOT NULL,
Cod_Pub INT NOT NULL
)
CREATE TABLE Titular(
DNI_Titular Varchar(9) NOT NULL,
Nombre Varchar(50) NOT NULL,
Domicilio Varchar(50) NULL,
Cod_Pub INT NOT NULL
)
CREATE TABLE Localidad(
Cod_Localidad INT IDENTITY (1,1) NOT NULL,
Nombre Varchar(50) NOT NULL
)
CREATE TABLE Empleado(
DNI_Empleado Varchar(9) NOT NULL,
Nombre Varchar(50) NOT NULL,
Domicilio Varchar(50) NULL
)
CREATE TABLE Pub_Empleado(
Cod_Pub INT NOT NULL,
DNI_Empleado Varchar(9) NOT NULL,
Funcion Varchar(9) NOT NULL
)

ALTER TABLE Localidad
ADD CONSTRAINT PK_Localidad_CodLocalidad PRIMARY KEY (Cod_Localidad)
ALTER TABLE Pub
ADD CONSTRAINT PK_Pub_CodPub PRIMARY KEY(Cod_Pub)
ALTER TABLE Pub
ADD CONSTRAINT FK_Pub_CodLocalidad FOREIGN KEY(Cod_Localidad)

REFERENCES Localidad(Cod_Localidad)
ALTER TABLE Existencias
ADD CONSTRAINT PK_Existencias_CodArticulo PRIMARY KEY(Cod_Articulo)
ALTER TABLE Existencias
ADD CONSTRAINT FK_Existencias_CodPub FOREIGN KEY(Cod_Pub)
REFERENCES Pub(Cod_Pub)
ALTER TABLE Titular
ADD CONSTRAINT PK_Titular_DNI PRIMARY KEY(DNI_Titular)
ALTER TABLE Titular
ADD CONSTRAINT FK_Titular_CodPub FOREIGN KEY(Cod_Pub)
REFERENCES Pub(Cod_Pub)
ALTER TABLE Empleado
ADD CONSTRAINT PK_Empleado_DNI PRIMARY KEY(DNI_Empleado)
ALTER TABLE Pub_Empleado
ADD CONSTRAINT PK_PubEmpleado_CodPub_DNI_Funcion
PRIMARY KEY (Cod_Pub, DNI_Empleado, Funcion)
ALTER TABLE Pub_Empleado
ADD CONSTRAINT FK_PubEmpleado_CodPub FOREIGN KEY (Cod_Pub)
REFERENCES Pub(Cod_Pub),
CONSTRAINT FK_PubEmpleado_DNI FOREIGN KEY (DNI_Empleado)
REFERENCES Empleado(DNI_Empleado)
ALTER TABLE Pub
ADD CONSTRAINT CK_Pub_Horario
CHECK (Horario IN('HOR1','HOR2','HOR3'))
ALTER TABLE Pub_Empleado
ADD CONSTRAINT CK_PubEmpleado_Funcion
CHECK (Funcion IN('CAMARERO','SEGURIDAD','LIMPIEZA'))
Select *from PUB
Select *from TITULAR
Select *from EMPLEADO
Select *from EXISTENCIAS
Select *from LOCALIDAD
Select *from PUB_EMPLEADO