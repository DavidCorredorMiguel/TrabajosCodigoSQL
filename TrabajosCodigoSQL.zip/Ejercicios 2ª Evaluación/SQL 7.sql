CREATE TABLE PruebaNumeros(
	NumInt int NOT NULL,
	NumTiny tinyint NOT NULL,
	NumSmallint smallint NOT NULL,
	NumBit bit NOT NULL,
	NumFloat float NOT NULL,
);
INSERT INTO PruebaNumeros(NumInt, NumTiny, NumSmallint, NumBit, NumFloat)
VALUES(1,2,3,0,4),
	(200,150,400,1,15.25),
	(125,100,250,0,5.5)
Select *from PruebaNumeros