CREATE TABLE Fabricante(
	CodFabricante int IDENTITY(1,1) NOT NULL,
	Nombre varchar(100) NOT NULL,
	CONSTRAINT PK_Fabricante_CodFabricante PRIMARY KEY(CodFabricante)
)
CREATE TABLE Articulos(
	CodArticulo int IDENTITY(1,1) NOT NULL,
	Nombre varchar(100) NOT NULL,
	Precio int NOT NULL,
	CodFabricante int NOT NULL,
	CONSTRAINT PK_Articulos_CodFab PRIMARY KEY(CodArticulo),
	CONSTRAINT FK_Articulos_CodFab FOREIGN KEY(CodFabricante)
	REFERENCES Fabricante(CodFabricante),
)
INSERT�INTO�Fabricante�(Nombre)
VALUES�('fabricante 1'),
('fabricante 2')
INSERT�INTO�Articulos�(Nombre,�Precio)
VALUES�('producto 1',�1),
('producto 2',�24),
('producto 3',�36),
('producto 4',�48),
('producto 5',�59),
('producto 6',�110),
('producto 7',�125),
('producto 8',�155),
('producto 9',�189)
SELECT * FROM Fabricante
SELECT * FROM Articulos

SELECT Nombre FROM Articulos

SELECT Nombre,Precio FROM Articulos

SELECT * FROM Articulos
WHERE Precio>=200

SELECT * FROM Articulos
WHERE Precio BETWEEN 60 AND 120

SELECT Nombre, (Precio * 166.386) As PrecioPesetas FROM Articulos

SELECT AVG(Precio) AS PrecioPromedio FROM Articulos

SELECT AVG(Precio) AS PrecioPromedio FROM Articulos
WHERE CodFabricante = 2

SELECT COUNT(Nombre) AS CountNombre FROM Articulos
WHERE Precio >= 180

SELECT Precio, Nombre FROM Articulos
WHERE Precio >= 180
Order by Precio desc, Nombre asc

SELECT Articulos.Nombre As NombreArticulo, Articulos.Precio, Fabricante.Nombre As NombreFabricante
FROM Articulos INNER JOIN Fabricante ON Articulos.CodFabricante = Fabricante.CodFabricante

SELECT Articulos.Nombre As NombreArticulo, Articulos.Precio, Fabricante.Nombre As NombreFabricante
FROM Articulos INNER JOIN Fabricante ON Articulos.CodFabricante = Fabricante.CodFabricante

SELECT Articulos.CodFabricante, AVG(Precio) As PrecioMedio
FROM Articulos 
GROUP BY Articulos.CodFabricante

SELECT Fabricante.Nombre As NombreFabricante, AVG(Precio) As PrecioMedio
FROM Articulos INNER JOIN Fabricante ON Articulos.CodFabricante = Fabricante.CodFabricante
GROUP BY Fabricante.Nombre

SELECT Fabricante.Nombre As NombreFabricante
FROM Articulos INNER JOIN Fabricante ON Articulos.CodFabricante = Fabricante.CodFabricante
GROUP BY Fabricante.Nombre
HAVING AVG(Precio) > 150

SELECT Articulos.Nombre, Articulos.Precio
FROM Articulos 
WHERE Precio = (Select MIN(Precio) FROM ARTICULOS)

SELECT Articulos.Nombre As NombreArticulo, Articulos.Precio, Fabricante.Nombre As NombreFabricante
FROM Articulos INNER JOIN Fabricante ON Articulos.CodFabricante = Fabricante.CodFabricante
AND Precio = (SELECT MAX(Precio) From Articulos art WHERE art.CodFabricante = Fabricante.CodFabricante)

INSERT�INTO�Articulos�(Nombre,�Precio, CodFabricante)
VALUES�('Altavoces',�70, 2)

UPDATE Articulos
SET Nombre = 'Impresora Laser'
WHERE CodArticulo = 8

UPDATE Articulos
SET Precio = Precio*0.9

UPDATE Articulos
SET Precio = Precio-10
WHERE Precio>=120