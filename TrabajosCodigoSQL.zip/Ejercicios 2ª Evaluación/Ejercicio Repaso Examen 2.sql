CREATE DATABASE GestionSalas 
USE GestionSalas;
GO
CREATE TABLE Maquinas(
  id int identity(1,1) constraint pk_maquinas primary key,
  nombre nvarchar(50) not null,
  procesador nvarchar(50) not null,
  memoria smallint not null,
  disco smallint not null,
  pantalla tinyint not null,
  constraint ck_memoria check (memoria>0),
  constraint ck_disco check (disco>0),
  constraint ck_pantalla check (pantalla>0)
);
GO
CREATE TABLE Cursos(
  id int identity(1,1) constraint pk_cursos primary key,
  codigo nvarchar(10),
  titulo nvarchar(60),
  duracion tinyint,
  programa xml
);
GO
CREATE TABLE CursosMaquinas(
  id int identity(1,1) constraint pk_cursosMaquinas primary key,
  cursos int constraint fk_cursosMaquinas_cursos references Cursos(id),
  maquina int constraint fk_cursosMaquinas_maquinas references Maquinas(id)
)
GO
CREATE TABLE Salas(
  id int identity(1,1) constraint pk_salas primary key,
  nombre nvarchar(20),
  numeroSitios smallint constraint ck_salas_numeroSitios check (numeroSitios>0),
  maquina int constraint fk_salas_maquinas references Maquinas(id)
);
GO
CREATE TABLE Formaciones(
  id int identity(1,1) constraint pk_formaciones primary key,
  cursos int constraint fk_formaciones_cursos references Cursos(id),
  sala int constraint fk_formaciones_salas references Salas(id),
  fechaInicio date,
  fechaFin date
);
USE GestionSalas;
Go
ALTER TABLE FORMACIONES ADD CONSTRAINT ck_formaciones_fecha CHECK (fechaFin is null or (fechaFin>fechaInicio));
USE GestionSalas;
GO
Print '----> tabla de Maquinas'
SET IDENTITY_INSERT Maquinas ON
INSERT Maquinas(id,nombre,procesador,memoria,disco,pantalla) 
VALUES(1,'860','Core i5',8,300,15),(2,'890','Core i5',8,300,15),
      (3,'960','Core i5',16,500,17),(4,'980','Core i7',16,500,17),
	  (5,'990','Core i7',16,1000,20);
SET IDENTITY_INSERT Maquinas OFF
Print '----> tabla de Cursos'
SET IDENTITY_INSERT Cursos ON
INSERT Cursos (id, codigo, titulo, duracion) 
VALUES (1,'T220-10054','Consultas  Transact-SQL para SQL Server ',3),
       (2,'T221-10775','Administraci�n de bases de datos  SQL Server',5),
	   (3,'T120-10967','Fundamentos de una infraestructura Windows',5),
	   (4,'T115-020','Linux/Unix: uso por l�nea de comandos',4),
	   (5,'T120-10970','Redes con Windows Server',5),
	   (6,'T127-VS501','VMware vSphere 5.1',4),
	   (7,'T325-20341','Principales soluciones de Microsoft Exchange Server',5),
	   (8,'T420-020','Modelizaci�n y dise�o UML',4),
	   (9,'T461-20483','Programaci�n en C#',5),
	   (10,'T461-20486','Desarrollo de aplicaciones Web ASP.NET MVC 4',5)
SET IDENTITY_INSERT Cursos OFF
Print '----> tabla CursosMaquinas'
SET IDENTITY_INSERT CursosMaquinas ON
INSERT CursosMaquinas (id, cursos, maquina)
VALUES ( 1,1,1),( 2,1,2),( 3,1,3),( 4,1,4),
	   ( 5,1,5),( 6,2,1),( 7,2,2),( 8,2,3),
	   ( 9,2,4),(10,2,5),(11,3,3),(12,3,4),
	   (13,3,5),(14,4,1),(15,4,2),(16,4,3),
	   (17,4,4),(18,4,5),(19,5,3),(20,5,4),
	   (21,5,5),(22,6,4),(23,6,5),(24,7,4),
	   (25,7,5),(26,8,1),(27,8,2),(28,8,3),
	   (29,8,4),(30,8,5),(31,9,5),(32,10,5)
SET IDENTITY_INSERT CursosMaquinas OFF
Print '----> tabla de Salas'
SET IDENTITY_INSERT Salas ON
INSERT Salas (id, nombre, numeroSitios, maquina)
VALUES ( 1,'Guadalquivir',10,1),( 2,'Duero',10,4),
	   ( 3,'Mi�o',12,2),( 4,'Guadiana',12,4),
	   ( 5,'Nervi�n',8,1),( 6,'Ebro',20,3),
	   ( 7,'J�car',10,5),( 8,'Segura',12,3),
	   ( 9,'Tajo',15,4),(10,'Turia',8,5)
SET IDENTITY_INSERT Salas OFF
Print '----> tabla de Formaciones'
SET IDENTITY_INSERT Formaciones ON
INSERT Formaciones(id, cursos, sala, fechaInicio, fechaFin)
VALUES (1,4,1,'28/04/2014','02/05/2014'),
	   (2,2,2,'02/06/2014','06/06/2014'),
	   (3,8,1,'02/06/2014','05/06/2014'),
	   (4,3,7,'16/06/2014','20/06/2014'),
	   (5,8,2,'15/07/2014','18/07/2014'),
	   (6,7,4,'07/07/2014','11/07/2014'),
	   (7,5,8,'25/08/2014','29/08/2014'),
	   (8,1,5,'02/06/2014','04/06/2014'),
	   (9,6,7,'01/09/2014','04/09/2014'),
	   (10,10,10,'01/09/2014','05/09/2014')
SET IDENTITY_INSERT Formaciones OFF

SELECT Id, nombre, numeroSitios FROM Salas

SELECT  Maquinas.nombre As nombreMaquina, Salas.Nombre As NombreSala FROM Maquinas
INNER JOIN Salas ON Salas.maquina = Maquinas.id

SELECT  Titulo, count(*)
FROM Cursos INNER JOIN
	CursosMaquinas ON Cursos.id = CursosMaquinas.cursos
GROUP BY Titulo

SELECT  Titulo
FROM Cursos INNER JOIN
Formaciones On Cursos.id = Formaciones.cursos
WHERE DATEDIFF(ww, GETDATE(), dateadd(ww,11,fechaInicio)) = 1

SELECT  nombre
From Salas
WHERE numerositios IN (SELECT MAX(numerositios) From salas)

SELECT * FROM Maquinas
WHERE id NOT IN(SELECT maquina from salas)

SELECT * FROM SALAS
WHERE id NOT IN(SELECT sala from formaciones)

SELECT Cursos.titulo, count(Maquina) As NumeroMaquina FROM CursosMaquinas
INNER JOIN Cursos ON CursosMaquinas.cursos = Cursos.id
GROUP BY Cursos.titulo
