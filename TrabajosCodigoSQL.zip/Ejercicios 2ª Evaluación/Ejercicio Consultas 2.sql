CREATE TABLE Empleado(
	DNI varchar(8) NOT NULL,
	Nombre nvarchar(100) NOT NULL,
	Apellidos nvarchar(255) NOT NULL,
	Departamento int NOT NULL,
	CONSTRAINT PK_Empleado_DNI PRIMARY KEY(DNI),
	CONSTRAINT FK_Empleado_Departamento FOREIGN KEY(Departamento)
	REFERENCES Empleado(Departamento),
)
CREATE TABLE Departamento(
	Codigo int IDENTITY(1,1) NOT NULL,
	Nombre varchar(100) NOT NULL,
	Presupuesto int NOT NULL,
	CONSTRAINT PK_Departamento_Codigo PRIMARY KEY(Codigo),
)

INSERT�INTO�Empleado�(DNI, Nombre, Apellidos, Departamento)
VALUES�('3459596M', 'empleado 1', 'L�pez', 14),
('3459596T', 'empleado 2', 'P�rez', 37),
('3459596N', 'empleado 3', 'Pablo', 77)

INSERT�INTO�Departamento�(Nombre,�Presupuesto)
VALUES�('Departamento 1',�10000),
('Departamento 2',�24000),
('Departamento 3',�36000),
('Departamento 4',�78000),
('Departamento 5',�89000),
('Departamento 6',�78000),
('Departamento 7',�78000),
('Departamento 8',�78000),
('Departamento 9',�78000),
('Departamento 10',�78000),
('Departamento 11',�78000),
('Departamento 12',�78000),
('Departamento 13',�78000),
('Departamento Informatica',�78000)

SELECT * FROM Empleado
SELECT * FROM Departamento

SELECT Apellidos FROM Empleado

SELECT DISTINCT Apellidos FROM Empleado

SELECT Apellidos FROM Empleado WHERE Apellidos='L�pez'

SELECT Apellidos FROM Empleado WHERE Apellidos IN ('L�pez', 'P�rez')

SELECT Departamento FROM Empleado WHERE Departamento=14

SELECT Departamento FROM Empleado WHERE Departamento IN(37,77)

SELECT Apellidos FROM Empleado WHERE Apellidos LIKE 'P%'

SELECT SUM(Presupuesto) FROM Departamentos

SELECT Departamento.Nombre As NombreDepartamento, COUNT(Empleado.DNI) As NumEmpleados
FROM Departamento LEFT JOIN Empleado ON Departamento.Codigo = Empleado.Departamento
GROUP BY Departamento.Codigo,Departamento.Nombre
ORDER BY Departamento.Codigo

SELECT Departamento.Codigo, Departamento.Nombre
As NombreDepartamento, Departamento.Presupuesto, Empleado.DNI, Empleado.Nombre
As NombreEmpleado, Empleado.Apellidos
FROM Departamento INNER JOIN Empleado ON Departamento.Codigo = Empleado.Departamento

SELECT Departamento.Nombre As NombreDepartamento, Departamento.Presupuesto, Empleado.Nombre
As NombreEmpleado, Empleado.Apellidos
FROM Departamento INNER JOIN Empleado ON Departamento.Codigo = Empleado.Departamento

SELECT Empleado.Nombre As NombreEmpleado, Empleado.Apellidos
FROM Departamento INNER JOIN Empleado ON Departamento.Codigo = Empleado.Departamento
WHERE Presupuesto>60000

SELECT Departamento.Nombre FROM Departamento
WHERE Presupuesto > (SELECT AVG(Presupuesto) AS MediaPresupuesto FROM Departamento)

SELECT Departamento.Nombre
FROM Departamento INNER JOIN Empleado ON Departamento.Codigo = Empleado.Departamento
GROUP BY Departamento.Nombre
HAVING COUNT(DNI) > 2

INSERT�INTO�Departamento�(Nombre,�Presupuesto, Codigo)
VALUES�('Calidad',�40000, 11)

INSERT�INTO�Empleado�(DNI, Nombre, Apellidos, Departamento)
VALUES�('89267109M', 'Esther', 'V�zquez', 78)

UPDATE Departamento
SET Presupuesto = Presupuesto*0.9

UPDATE Empleado
SET Departamento=14
WHERE Departamento=77

DELETE Empleado
WHERE Departamento=14

DELETE Empleado
WHERE Departamento IN(SELECT Codigo FROM Departamento WHERE Presupuesto>60000)

DELETE FROM Empleado