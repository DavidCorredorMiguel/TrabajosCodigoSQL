CREATE TABLE Cliente(
	DNI Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Apellidos Varchar(30) NOT NULL,
	Direccion Varchar(50) NULL,
	FechaNacimiento Date NULL,
	CONSTRAINT PK_Cliente_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Proveedor(
	CodProveedor Int IDENTITY(1,1) NOT NULL,
	CIF Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Direccion Varchar(50) NULL,
	CONSTRAINT PK_Proveedor_CodProveedor PRIMARY KEY(CodProveedor),
	CONSTRAINT UQ_Proveedor_Cif UNIQUE(CIF)
)
CREATE TABLE Producto(
	CodProducto Int IDENTITY(1,1) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Codigo Varchar(10) NOT NULL,
	Precio Float NOT NULL,
	Descripcion Varchar(500) NULL,
	CodProveedor Int NOT NULL,
	CONSTRAINT PK_Producto_CodProducto PRIMARY KEY(CodProducto),
	CONSTRAINT FK_Producto_CodProveedor FOREIGN KEY(CodProveedor)
	REFERENCES Proveedor(CodProveedor),
	CONSTRAINT UQ_Producto_Codigo UNIQUE(Codigo)
)
CREATE TABLE Compras(
	DNI_Cliente Varchar(9) NOT NULL,
	CodProducto Int NOT NULL,
	FechaCompra Datetime NOT NULL,
	Unidades TinyInt NOT NULL,
	CONSTRAINT PK_Compras_DNIProductoFecha PRIMARY KEY(DNI_Cliente,
	CodProducto,FechaCompra),
	CONSTRAINT FK_Compras_DNI FOREIGN KEY(DNI_Cliente)
	REFERENCES Cliente(DNI),
	CONSTRAINT FK_Compras_CodProducto FOREIGN KEY(CodProducto)
	REFERENCES Producto(CodProducto),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades BETWEEN 0 AND 100),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades > 0 AND Unidades < 100)
)

INSERT�INTO�Cliente�(DNI, Nombre, Apellidos, Direccion, FechaNacimiento)
VALUES�('3459596M', 'Cliente 1', 'L�pez', 'C\Nueva 1', '2000-5-14'),
('3459596N', 'Cliente 2', 'Pablo', 'C\Nueva 5', '2001-5-27')

INSERT�INTO�Compras (DNI_Cliente, FechaCompra, Unidades)
VALUES�('3459596M', '2015-5-14', 2),
('3459596N', '2015-5-27', 3)

INSERT�INTO�Producto (Nombre, Codigo, Precio, Descripcion)
VALUES�('Producto 1', '3459596MN', 14, 'Producto 1 Descripcion'),
('Producto 2', '3459596MC', 27, 'Producto 3 Descripcion')

INSERT�INTO�Proveedor(CIF, Nombre, Direccion)
VALUES�('3459596T', 'Proveedor 1', 'C\Nueva 1'),
('3459596O', 'Proveedor 2','C\Nueva 5')

DELETE Producto WHERE CodProducto=1

SELECT DNI, Nombre, Apellidos, Direccion, CONVERT(varchar, FechaNacimiento, 1) AS FechaNacimiento,
FORMAT(FechaNacimiento, 'dd/mm/yyyy') AS FechaNacimientoFormat FROM Cliente

SELECT Cliente.Nombre As NombreCliente, COUNT(Compras.DNI_Cliente) AS Compras
FROM Cliente INNER JOIN Compras ON Cliente.DNI = Compras.DNI_Cliente
GROUP BY Cliente.Nombre

SELECT Cliente.Nombre, Producto.Nombre AS NombreProducto, Compras.Unidades, Compras.FechaCompra
FROM Cliente INNER JOIN Compras ON Cliente.DNI = Compras.DNI_Cliente
INNER JOIN Producto ON Compras.CodProducto = Producto.CodProducto

SELECT Nombre FROM Producto
WHERE (CodProducto IN (SELECT DISTINCT CodProducto FROM  Compras))

SELECT Producto.Nombre AS NombreProducto, Proveedor.CIF, Proveedor.Nombre AS NombreProveedor
FROM Producto INNER JOIN Proveedor ON Producto.CodProveedor = Proveedor.CodProveedor

SELECT Compras.DNI_Cliente, AVG(Producto.Precio) AS PrecioMedioCompra
FROM Compras INNER JOIN Producto ON Compras.CodProducto = Producto.CodProducto
GROUP BY Compras.DNI_Cliente

SELECT RIGHT(Codigo,3) AS CodigoFinal FROM Producto

SELECT Nombre AS NombreCliente, LEFT(DNI, 8) As DNICorto,
DATEDIFF(DAY,FechaNacimiento,GETDATE()) As DiferenciaDias FROM Cliente