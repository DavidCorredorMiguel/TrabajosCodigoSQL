CREATE TABLE Representaciones(
Cod_Espectaculo Int NOT NULL,
Fecha DATE NOT NULL,
Hora time NOT NULL,
CONSTRAINT PK_Representacion_CodEspectaculo PRIMARY KEY(Cod_Espectaculo)
)
CREATE TABLE Recintos(
Cod_Recinto Int IDENTITY (1,1) NOT NULL,
Nombre Varchar(50) NOT NULL,
Direccion varchar(50) NOT NULL,
Ciudad Varchar(50) NOT NULL,
Telefono Varchar(9) NOT NULL,
Horario varchar(50) NOT NULL,
CONSTRAINT PK_Recintos_CodRecinto PRIMARY KEY(Cod_Recinto)
)
CREATE TABLE Precios_Espectaculos(
Cod_Espectaculo Int NOT NULL,
Cod_Recinto INT NOT NULL,
Zona Varchar(50) NOT NULL,
Precio Float NOT NULL,
CONSTRAINT PK_PreciosEspectaculos_CodEspectaculoRecintoZona
PRIMARY KEY(Cod_Espectaculo, Cod_Recinto,Zona),
CONSTRAINT FK_PreciosEspectaculos_CodEspectaculo FOREIGN KEY(Cod_Espectaculo)
REFERENCES Representaciones(Cod_Espectaculo),
CONSTRAINT FK_PreciosEspectaculos_CodRecinto FOREIGN KEY (Cod_Recinto)
REFERENCES Recintos(Cod_Recinto)
)

CREATE TABLE Espectaculos(
Cod_Espectaculo Int IDENTITY (1,1) NOT NULL,
Nombre Varchar(50) NOT NULL,
Tipo varchar(50) NOT NULL,
Fecha_Inicial Datetime NOT NULL,
Fecha_Final Datetime NOT NULL,
Interprete varchar(50)NOT NULL,
Cod_Recinto INT NOT NULL,
CONSTRAINT PK_Espectaculos_CodEspectaculo PRIMARY KEY(Cod_Espectaculo),
CONSTRAINT FK_Espectaculos_CodRecinto FOREIGN KEY(Cod_Recinto)
REFERENCES Recintos(Cod_Recinto)
)
CREATE TABLE Zonas_Recintos(
Cod_Recinto Int NOT NULL,
Zona Varchar(50) NOT NULL,
Capacidad Smallint NOT NULL,
CONSTRAINT PK_ZonasRecintos_CodRecintoZona PRIMARY KEY(Cod_Recinto, Zona),
CONSTRAINT FK_ZonaRecintos_CodRecinto FOREIGN KEY(Cod_Recinto)
REFERENCES Recintos(Cod_Recinto)
)
CREATE TABLE Asientos(
Cod_Recinto Int NOT NULL,
Zona Varchar(50) NOT NULL,
Fila Tinyint NOT NULL,
Numero Smallint NOT NULL,
CONSTRAINT FK_Asientos_CodRecinto FOREIGN KEY(Cod_Recinto)
REFERENCES Recintos(Cod_Recinto)
)
CREATE TABLE Espectadores(
DNI_Cliente Varchar(9) NOT NULL,
Nombre Varchar(50) NOT NULL,
Direccion Varchar(50) NOT NULL,
Telefono Varchar(9) NOT NULL,
Ciudad Varchar(50) NOT NULL,
NTarjeta Varchar(16) NOT NULL,
CONSTRAINT PK_Espectadores_DNICliente PRIMARY KEY(DNI_Cliente)
)
CREATE TABLE Entradas(
Cod_Espectaculo Int NOT NULL,
Fecha Date NOT NULL,
Hora Time NOT NULL,
Cod_Recinto Int NOT NULL,
Fila Tinyint NOT NULL,
Numero Smallint NOT NULL,
Zona Varchar(50) NOT NULL,
DNI_Cliente Varchar(9) NOT NULL,
CONSTRAINT FK_Entradas_CodRecinto FOREIGN KEY(Cod_Recinto)
REFERENCES Recintos(Cod_Recinto),
CONSTRAINT FK_Entradas_DNIClientes FOREIGN KEY(DNI_Cliente)
REFERENCES Espectadores(DNI_Cliente)
)