CREATE TABLE Empleados(
DNI Varchar(8) NOT NULL,
Nombre Varchar(10) NOT NULL,
Apellido1 Varchar(15) NOT NULL,
Apellido2 Varchar(15) NULL,
Direcc1 Varchar(25) NULL,
Direcc2 Varchar(20) NULL,
Ciudad Varchar(20) NULL,
Provincia Varchar(20) NULL,
Cod_Postal Varchar(5) NULL,
Sexo Char(1) NULL,
Fecha_Nac Date NULL,
CONSTRAINT CK_Empleados_Sexo CHECK(Sexo IN('H','M')),
CONSTRAINT PK_Empleados_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Departamentos(
DPTO_Cod Smallint NOT NULL IDENTITY(1,1),
Nombre_DPTO Varchar(30) NOT NULL,
DPTO_Padre Smallint NULL,
Presupuesto Float NOT NULL,
Pres_Actual Float NULL,
CONSTRAINT UN_Departamentos_Nombre UNIQUE(Nombre_DPTO),
CONSTRAINT PK_Departamentos_CodDep PRIMARY KEY(DPTO_Cod)
)
CREATE TABLE Trabajos(
Trabajo_Cod Smallint NOT NULL IDENTITY(1,1),
Nombre_Trab Varchar(20) NOT NULL,
Salario_Min Float NOT NULL,
Salario_Max Float NOT NULL,
CONSTRAINT UN_Trabajos_Nombre UNIQUE(Nombre_Trab),
CONSTRAINT PK_Trabajos_CodTra PRIMARY KEY(Trabajo_Cod)
)
CREATE TABLE Historial_Laboral(
Empleado_DNI Varchar(8) NOT NULL,
Trabajo_Cod Smallint NOT NULL,
Fecha_Inicio Date NOT NULL,
Fecha_Fin Date NULL,
DPTO_Cod Smallint NULL,
Supervisor_DNI Varchar(8) NULL,
CONSTRAINT PK_HLaboral_EmpTraFec PRIMARY KEY
(Empleado_DNI,Trabajo_Cod,Fecha_Inicio),
CONSTRAINT FK_HLaboral_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI),
CONSTRAINT FK_HLaboral_CodTrab FOREIGN KEY(Trabajo_Cod)
REFERENCES Trabajos(Trabajo_Cod),
CONSTRAINT FK_HLaboral_DPTO FOREIGN KEY(DPTO_Cod)
REFERENCES Departamentos(DPTO_Cod),
CONSTRAINT FK_HLaboral_Supervisor FOREIGN KEY(Supervisor_DNI)
REFERENCES Empleados(DNI)
)
CREATE TABLE Historial_Salarial(
Empleado_DNI Varchar(8) NOT NULL,
Salario Float NOT NULL,
Fecha_Comienzo Date NOT NULL,
Fecha_Fin Date NULL,
CONSTRAINT PK_HSalarial_EmpSalFec PRIMARY KEY
(Empleado_DNI,Salario,Fecha_Comienzo),
CONSTRAINT FK_HSalarial_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI)
)
CREATE TABLE Universidades(
Univ_Cod smallint NOT NULL IDENTITY(1,1),
Nombre_Univ Varchar(25) NOT NULL,
Ciudad Varchar(20) NULL,
Municipio Varchar(20) NULL,
Cod_Postal Varchar(5) NULL,
CONSTRAINT PK_Universidades_CodUni PRIMARY KEY(Univ_Cod)
)
CREATE TABLE Estudios(
Empleado_DNI Varchar(8) NOT NULL,
Universidad Smallint NULL,
A�o SmallInt NULL,
Grado Varchar(3) NULL,
Especialidad Varchar(20) NULL,
CONSTRAINT FK_Estudios_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI),
CONSTRAINT FK_Estudios_CodUniversidad FOREIGN KEY (Universidad)
REFERENCES Universidades(Univ_Cod)
)
INSERT�INTO�empleados�( nombre,�apellido1,�apellido2,�dni,�sexo�)
VALUES�('Sergio',�'Palma',�'Entrena',�'111222',�'H')
INSERT�INTO�empleados�( nombre,�apellido1,�apellido2,�dni,�sexo)
VALUES�('Lucia',�'Ortega',�'Plus',�'222333',�NULL)�;
INSERT�INTO�historial_laboral�( empleado_dni, Trabajo_Cod, fecha_inicio, fecha_fin,
dpto_cod, supervisor_dni�)
VALUES�('111222', 1, '2010-01-01', NULL, NULL, '222333') ;
DELETE Universidades
WHERE Univ_Cod = 2
ALTER TABLE Empleados
ADD Valoracion Tinyint NOT NULL DEFAULT(5)
ALTER TABLE Empleados
ADD CONSTRAINT CK_Empleado_Valoracion CHECK(Valoracion > 0 AND Valoracion < 10)
ALTER TABLE Empleados
ALTER COLUMN Nombre Varchar(10) NULL
ALTER TABLE Empleados
ALTER COLUMN Direcc1 Varchar(40) NULL
ALTER TABLE Empleados
DROP CONSTRAINT PK_Empleados_DNI
Select *from EMPLEADOS
Select *from HISTORIAL_LABORAL
Select *from HISTORIAL_SALARIAL
Select *from DEPARTAMENTOS
Select *from ESTUDIOS
Select *from UNIVERSIDADES
Select *from TRABAJOS
DELETE from EMPLEADOS
DELETE from HISTORIAL_LABORAL
DELETE from HISTORIAL_SALARIAL
DELETE from DEPARTAMENTOS
DELETE from ESTUDIOS
DELETE from UNIVERSIDADES
DELETE from TRABAJOS