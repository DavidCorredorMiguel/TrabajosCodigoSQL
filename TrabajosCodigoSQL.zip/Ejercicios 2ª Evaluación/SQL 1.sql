SELECT			*
FROM			spt_monitor