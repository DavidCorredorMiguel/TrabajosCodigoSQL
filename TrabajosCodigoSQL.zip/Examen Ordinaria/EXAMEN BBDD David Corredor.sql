CREATE TABLE ALMACENES(
	CodigoAlmacen int IDENTITY (1,1) NOT NULL,
	Lugar varchar(100) NOT NULL,
	Capacidad int NULL
	CONSTRAINT PK_ALMACENES_CodigoAlmacen PRIMARY KEY(CodigoAlmacen)
)
CREATE TABLE TIPOCAJA(
	IdTipoCaja tinyint IDENTITY (1,1) NOT NULL,
	Tipo varchar(50) NOT NULL
	CONSTRAINT PK_TIPOCAJA_IdTipoCaja PRIMARY KEY(IdTipoCaja)
)
CREATE TABLE CAJAS(
	NumReferencia varchar(5) NOT NULL,
	Contenido varchar(100) NOT NULL,
	Valor float NULL,
	CodigoAlmacen int NOT NULL,
	IdTipoCaja tinyint NOT NULL
	CONSTRAINT PK_CAJAS_NumReferencia PRIMARY KEY(NumReferencia)
	CONSTRAINT FK_CAJAS_CodigoAlmacen FOREIGN KEY(CodigoAlmacen)
	REFERENCES ALMACENES(CodigoAlmacen),
	CONSTRAINT FK_CAJAS_IdTipoCaja FOREIGN KEY(IdTipoCaja)
	REFERENCES TIPOCAJA(IdTipoCaja)
)

INSERT INTO ALMACENES (Lugar, Capacidad)
VALUES ('Bilbao', 1),
('M�laga', 1),
('Madrid', 5)
INSERT INTO TIPOCAJA(Tipo)
VALUES ('Grande'),
('Peque�a')
INSERT INTO CAJAS(NumReferencia, Contenido, Valor)
VALUES ('14587', 'Cartera', 19.99),
('25795', 'Televisi�n', 290),
('11112', 'Cartera', 50)

SELECT CodigoAlmacen FROM CAJAS WHERE AVG(Valor)>150

SELECT RIGHT(CAJAS.NumReferencia, 3), LEFT(ALMACENES.Lugar, 2) FROM CAJAS
INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen

CREATE PROCEDURE procedimiento
@numcajas int
AS
	BEGIN TRAN transaccion
	BEGIN TRY
		DECLARE @CodigoAl int
		DECLARE @lugaral varchar(100)
		DECLARE @capacidadal int
		DECLARE cursor1 CURSOR FOR
		if (COUNT(CodigoAlmacen)>Capacidad FROM ALMACENES)
		UPDATE ALMACENES SET Capacidad=Capacidad*2
		COMMIT TRAN transaccion
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN transaccion
		PRINT 'ERROR'
	END CATCH
GO

CREATE TRIGGER trigger1 ON CAJAS
FOR UPDATE
AS
BEGIN
	DECLARE @valores float
	SET @valores=(SELECT Valor FROM inserted)
	DECLARE @valores2 float
	SET @valores=(SELECT TOP 1 Valor FROM inserted)
	if (@valores<@valores2)
	ROLLBACK TRANSACTION
END

CREATE FUNCTION DBO.funcion (@codalmacen int)
RETURNS varchar(50)
AS
BEGIN
	DECLARE @cajagrande varchar(50) NOT NULL
	SET @cajagrande = (SELECT COUNT(ALMACENES.CodigoAlmacen) AS totalgrande FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Grande' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajagrande
	DECLARE @cajapeque varchar(50) NOT NULL
	SET @cajapeque = (SELECT COUNT(ALMACENES.CodigoAlmacen) AS totalpeque FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Peque�a' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajapeque
	DECLARE @cajagrandem varchar(50) NOT NULL
	SET @cajagrandem = (SELECT AVG(CAJAS.Valor) AS mediagrande FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Grande' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajagrandem
	DECLARE @cajapequem varchar(50) NOT NULL
	SET @cajapequem = (SELECT AVG(CAJAS.Valor) AS mediapeque FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Peque�a' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajapequem
	DECLARE @cajagrandemax varchar(50) NOT NULL
	SET @cajagrandemax = (SELECT MAX(CAJAS.Valor) AS maxgrande FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Grande' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajagrandemax
	DECLARE @cajapequemax varchar(50) NOT NULL
	SET @cajapequemax = (SELECT MAX(CAJAS.Valor) AS maxpeque FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Peque�a' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajapequemax
	DECLARE @cajagrandemin varchar(50) NOT NULL
	SET @cajagrandemin = (SELECT MIN(CAJAS.Valor) AS mingrande FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Grande' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajagrandemin
	DECLARE @cajapequemin varchar(50) NOT NULL
	SET @cajapequemin = (SELECT MIN(CAJAS.Valor) AS minpeque FROM CAJAS
	INNER JOIN ALMACENES ON ALMACENES.CodigoAlmacen=CAJAS.CodigoAlmacen
	INNER JOIN TIPOCAJA ON TIPOCAJA.IdTipoCaja=CAJAS.IdTipoCaja WHERE TIPOCAJA.Tipo='Peque�a' AND ALMACENES.CodigoAlmacen=@codalmacen)
	RETURN @cajapequemin
END

