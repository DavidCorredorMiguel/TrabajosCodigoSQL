CREATE TABLE Empleados(
DNI Varchar(8) NOT NULL,
Nombre Varchar(10) NOT NULL,
Apellido1 Varchar(15) NOT NULL,
Apellido2 Varchar(15) NULL,
Direcc1 Varchar(25) NULL,
Direcc2 Varchar(20) NULL,
Ciudad Varchar(20) NULL,
Provincia Varchar(20) NULL,
Cod_Postal Varchar(5) NULL,
Sexo Char(1) NULL,
Fecha_Nac Date NULL,
CONSTRAINT CK_Empleados_Sexo CHECK(Sexo IN('H','M')),
CONSTRAINT PK_Empleados_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Departamentos(
DPTO_Cod Smallint NOT NULL IDENTITY(1,1),
Nombre_DPTO Varchar(30) NOT NULL,
DPTO_Padre Smallint NULL,
Presupuesto Float NOT NULL,
Pres_Actual Float NULL,
CONSTRAINT UN_Departamentos_Nombre UNIQUE(Nombre_DPTO),
CONSTRAINT PK_Departamentos_CodDep PRIMARY KEY(DPTO_Cod)
)
CREATE TABLE Trabajos(
Trabajo_Cod Smallint NOT NULL IDENTITY(1,1),
Nombre_Trab Varchar(20) NOT NULL,
Salario_Min Float NOT NULL,
Salario_Max Float NOT NULL,
CONSTRAINT UN_Trabajos_Nombre UNIQUE(Nombre_Trab),
CONSTRAINT PK_Trabajos_CodTra PRIMARY KEY(Trabajo_Cod)
)
CREATE TABLE Historial_Laboral(
Empleado_DNI Varchar(8) NOT NULL,
Trabajo_Cod Smallint NOT NULL,
Fecha_Inicio Date NOT NULL,
Fecha_Fin Date NULL,
DPTO_Cod Smallint NULL,
Supervisor_DNI Varchar(8) NULL,
CONSTRAINT PK_HLaboral_EmpTraFec PRIMARY KEY
(Empleado_DNI,Trabajo_Cod,Fecha_Inicio),
CONSTRAINT FK_HLaboral_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI),
CONSTRAINT FK_HLaboral_CodTrab FOREIGN KEY(Trabajo_Cod)
REFERENCES Trabajos(Trabajo_Cod),
CONSTRAINT FK_HLaboral_DPTO FOREIGN KEY(DPTO_Cod)
REFERENCES Departamentos(DPTO_Cod),
CONSTRAINT FK_HLaboral_Supervisor FOREIGN KEY(Supervisor_DNI)
REFERENCES Empleados(DNI)
)
CREATE TABLE Historial_Salarial(
Empleado_DNI Varchar(8) NOT NULL,
Salario Float NOT NULL,
Fecha_Comienzo Date NOT NULL,
Fecha_Fin Date NULL,
CONSTRAINT PK_HSalarial_EmpSalFec PRIMARY KEY
(Empleado_DNI,Salario,Fecha_Comienzo),
CONSTRAINT FK_HSalarial_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI)
)
CREATE TABLE Universidades(
Univ_Cod smallint NOT NULL IDENTITY(1,1),
Nombre_Univ Varchar(25) NOT NULL,
Ciudad Varchar(20) NULL,
Municipio Varchar(20) NULL,
Cod_Postal Varchar(5) NULL,
CONSTRAINT PK_Universidades_CodUni PRIMARY KEY(Univ_Cod)
)
CREATE TABLE Estudios(
Empleado_DNI Varchar(8) NOT NULL,
Universidad Smallint NULL,
A�o SmallInt NULL,
Grado Varchar(3) NULL,
Especialidad Varchar(20) NULL,
CONSTRAINT FK_Estudios_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI),
CONSTRAINT FK_Estudios_CodUniversidad FOREIGN KEY (Universidad)
REFERENCES Universidades(Univ_Cod)
)
INSERT�INTO�empleados�( nombre,�apellido1,�apellido2,�dni,�sexo�)
VALUES�('Sergio',�'Palma',�'Entrena',�'111222',�'H')
INSERT�INTO�empleados�( nombre,�apellido1,�apellido2,�dni,�sexo)
VALUES�('Lucia',�'Ortega',�'Plus',�'222333',�NULL)�;
INSERT�INTO�historial_laboral�( empleado_dni, Trabajo_Cod, fecha_inicio, fecha_fin,
dpto_cod, supervisor_dni�)
VALUES�('111222', 1, '2010-01-01', NULL, NULL, '222333') ;

CREATE PROCEDURE USP_Tr1
@DNIem Varchar(8),
@Nombreem Varchar(10),
@Apellido1em Varchar(15),
@Apellido2em Varchar(15),
@Direcc1em Varchar(25),
@Direcc2em Varchar(20),
@Ciudadem Varchar(20),
@Provinciaem Varchar(20),
@Cod_Postalem Varchar(5),
@Sexoem Char(1),
@Fecha_Nacem Date,
AS 
BEGIN TRAN BK
BEGIN TRY
	INSERT�INTO�empleados�( nombre,�apellido1,�apellido2,�dni,�sexo�)
	VALUES�(@Nombreem,�@Apellido1em,�@Apellido2em,�@DNIem,�@Sexoem�) ;	
	PRINT 'TRANSACCION COMPLETADA'
COMMIT TRAN BK
END TRY
BEGIN CATCH 
	PRINT 'No se puede ejecutar'
END CATCH 
GO

CREATE PROCEDURE USP_Tr2
@Empleado_DNIhs Varchar(8),
@Salariohs Float,
@Fecha_Comienzohs Date,
@Fecha_Finhs Date,
AS 
BEGIN TRAN BK
BEGIN TRY
	INSERT�INTO�historial_salarial�( empleado_dni, salario, fecha_comienzo, fecha_fin)
	VALUES�(@Empleado_DNIhs, @Salariohs, @Fecha_Comienzohs, @Fecha_Finhs) ;
	UPDATE Historial_Salarial SET Salario=Salario*0.2
	UPDATE Historial_Salarial SET Fecha_Comienzo='2020-05-19'
	UPDATE Historial_Salarial SET Fecha_Fin='2020-05-18'
	PRINT 'TRANSACCION COMPLETADA'
COMMIT TRAN BK
END TRY
BEGIN CATCH 
	PRINT 'No se puede ejecutar'
END CATCH 
GO

CREATE PROCEDURE USP_Tr3
AS 
BEGIN TRAN BK
BEGIN TRY
	DELETE Empleados WHERE DNI='111222'
	DELETE Historial_Laboral WHERE Empleado_DNI='111222'
	DELETE Historial_Salarial WHERE Empleado_DNI='111222'
	DELETE Estudios WHERE Empleado_DNI='111222'
	PRINT 'TRANSACCION COMPLETADA'
COMMIT TRAN BK
END TRY
BEGIN CATCH 
	PRINT 'No se puede ejecutar'
END CATCH 
GO

CREATE PROCEDURE USP_Tr4
AS
BEGIN TRAN BK
BEGIN TRY 
	CREATE TABLE Trabajos(
	Trabajo_Cod Smallint NOT NULL IDENTITY(1,1),
	Nombre_Trab Varchar(20) NOT NULL,
	Salario_Min Float NOT NULL,
	Salario_Max Float NOT NULL,
	CONSTRAINT UN_Trabajos_Nombre UNIQUE(Nombre_Trab),
	CONSTRAINT PK_Trabajos_CodTra PRIMARY KEY(Trabajo_Cod)
	)
	DECLARE CursorIns CURSOR FOR
	INSERT�INTO�Trabajos( Nombre_Trab, Salario_Min, Salario_Max )
	VALUES�('SL',�1000,�22333)�;
	OPEN CursorInS 
	CLOSE CursorInS 
	DEALLOCATE CursorInS 
	PRINT 'TRANSACCION COMPLETADA'
COMMIT TRAN BK
END TRY
BEGIN CATCH
	PRINT 'No se puede ejecutar'
END CATCH
GO 