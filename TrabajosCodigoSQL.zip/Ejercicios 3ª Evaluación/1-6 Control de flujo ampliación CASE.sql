--Ejemplo: Declare una variable donde le asigne el numero del mes, eval�e el valor de la variable y devuelva el mes en letras.
DECLARE @M INT, @MES VARCHAR(20)
SET @M=4 --ir jugando con este valor para que te devuelva el mes correspondiente
SET @MES = (CASE @M
			WHEN 1 THEN 'ENERO'
			WHEN 2 THEN 'FEBRERO'
			WHEN 3 THEN 'MARZO'
			WHEN 4 THEN 'ABRIL'
			WHEN 5 THEN 'MAYO'
			WHEN 6 THEN 'JUNIO'
			WHEN 7 THEN 'JULIO'
			WHEN 8 THEN 'AGOSTO'
			WHEN 9 THEN 'SETIEMBRE'
			WHEN 10 THEN 'OCTUBRE'
			WHEN 11 THEN 'NOVIEMBRE'
			WHEN 12 THEN 'DICIEMBRE'
			ELSE 'NO ES MES VALIDO'
END)
PRINT @MES


--ejemplo
--si el tel�fono empieza por 6 � 7 es un m�vil, si empieza por 9 es un fijo, si es blanco no tiene
--dos maneras:

SELECT nombre,apellido, (CASE LEFT(telefono,1)
							WHEN '6' THEN 'M�vil'
							WHEN '7' THEN 'M�vil'
							WHEN '9' THEN 'Fijo'
							WHEN ''	THEN 'No tiene'
END) as 'Informaci�n del tel�fono'
FROM CLIENTES



SELECT nombre,apellido, (CASE
							WHEN LEFT(telefono,1) = '6' OR LEFT(telefono,1) = '7' THEN 'M�vil'
							WHEN LEFT(telefono,1) = '9' THEN 'Fijo'
							WHEN LEFT(telefono,1) = ''	THEN 'No tiene'
END) as 'Informaci�n del tel�fono'
FROM CLIENTES