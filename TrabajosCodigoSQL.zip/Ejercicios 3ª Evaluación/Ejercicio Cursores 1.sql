CREATE TABLE Cliente(
	DNI Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Apellidos Varchar(30) NOT NULL,
	Direccion Varchar(50) NULL,
	FechaNacimiento Date NULL,
	CONSTRAINT PK_Cliente_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Proveedor(
	CodProveedor Int IDENTITY(1,1) NOT NULL,
	CIF Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Direccion Varchar(50) NULL,
	CONSTRAINT PK_Proveedor_CodProveedor PRIMARY KEY(CodProveedor),
	CONSTRAINT UQ_Proveedor_Cif UNIQUE(CIF)
)
CREATE TABLE Producto(
	CodProducto Int IDENTITY(1,1) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Codigo Varchar(10) NOT NULL,
	Precio Float NOT NULL,
	Descripcion Varchar(500) NULL,
	CodProveedor Int NOT NULL,
	CONSTRAINT PK_Producto_CodProducto PRIMARY KEY(CodProducto),
	CONSTRAINT FK_Producto_CodProveedor FOREIGN KEY(CodProveedor)
	REFERENCES Proveedor(CodProveedor),
	CONSTRAINT UQ_Producto_Codigo UNIQUE(Codigo)
)
CREATE TABLE Compras(
	DNI_Cliente Varchar(9) NOT NULL,
	CodProducto Int NOT NULL,
	FechaCompra Datetime NOT NULL,
	Unidades TinyInt NOT NULL,
	CONSTRAINT PK_Compras_DNIProductoFecha PRIMARY KEY(DNI_Cliente,
	CodProducto,FechaCompra),
	CONSTRAINT FK_Compras_DNI FOREIGN KEY(DNI_Cliente)
	REFERENCES Cliente(DNI),
	CONSTRAINT FK_Compras_CodProducto FOREIGN KEY(CodProducto)
	REFERENCES Producto(CodProducto),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades > 0 AND Unidades < 100)
)

INSERT�INTO�Cliente�(DNI, Nombre, Apellidos, Direccion, FechaNacimiento)
VALUES�('46852869Y', 'Cliente 1', 'L�pez', 'C\Nueva 1', '2000-5-14'),
('3459596N', 'Cliente 2', 'Pablo', 'C\Nueva 5', '2001-5-27')

INSERT�INTO�Compras (DNI_Cliente, FechaCompra, Unidades)
VALUES�('3459596M', '2015-5-14', 2),
('3459596N', '2015-5-27', 3)

INSERT�INTO�Producto (Nombre, Codigo, Precio, Descripcion)
VALUES�('Producto 1', '3459596MN', 14, 'Producto 1 Descripcion'),
('Producto 2', '3459596MC', 27, 'Producto 3 Descripcion')

INSERT�INTO�Proveedor(CIF, Nombre, Direccion)
VALUES�('3459596T', 'Proveedor 1', 'C\Nueva 1'),
('3459596O', 'Proveedor 2','C\Nueva 5')

DECLARE @dni varchar(9)
DECLARE cursor1 CURSOR FOR
SELECT DNI FROM Cliente
OPEN cursor1
FETCH cursor1 INTO @dni
WHILE (@@FETCH_STATUS = 0)
BEGIN
	FETCH cursor1 INTO @dni
END
CLOSE cursor1

DECLARE @unidades TinyInt
DECLARE @nombre varchar(20)
DECLARE cursor2 CURSOR FOR 
SELECT Cliente.Nombre, Compras.Unidades
FROM Cliente INNER JOIN Compras ON Cliente.DNI = Compras.DNI_Cliente
OPEN cursor2
FETCH cursor2 INTO @unidades, @nombre
WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'Nombre cliente: ' + @nombre + 'Unidades: ' + @unidades
	FETCH cursor2 INTO @unidades, @nombre
END
CLOSE cursor2

DECLARE @cifprov Varchar(9)
DECLARE @nombreprov Varchar(20)
DECLARE @direccionprov Varchar(50)
DECLARE cursor3 CURSOR FOR 
SELECT  @cifprov=CIF, @nombreprov=Nombre, @direccionprov=Direccion FROM Proveedor
OPEN cursor3
FETCH cursor3 INTO @cifprov, @nombreprov, @direccionprov
WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'Los valores del proveedor son: Nombres: '+ @nombreprov 
	+ ' La direcci�n es: ' + @direccionprov
	FETCH cursor3 INTO @cifprov, @nombreprov, @direccionprov
END
CLOSE cursor3

DECLARE @nombrecli varchar(20)
DECLARE @nombreprod varchar(20)
DECLARE @nombreprove varchar(20)
DECLARE cursor4 CURSOR FOR 
SELECT @nombrecli=Cliente.Nombre, @nombreprod=Producto.Nombre, @nombreprove=Proveedor.Nombre
FROM Cliente INNER JOIN Proveedor ON Cliente.DNI=Proveedor.CIF
INNER JOIN Producto ON Proveedor.CodProveedor=Producto.CodProveedor
OPEN cursor4
FETCH cursor4 INTO @cifprov, @nombreprov, @direccionprov
WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'Nombre cliente: ' + @nombrecli + 'Nombre producto: '+ @nombreprod + 'Nombre proveedor: '+ @nombreprove
	FETCH cursor4 INTO @cifprov, @nombreprov, @direccionprov
END
CLOSE cursor4

DECLARE @nombrepro varchar (20)
DECLARE @precio int
DECLARE cursor5 CURSOR FOR 
SELECT Nombre, Precio from Producto
OPEN cursor5
FETCH cursor5 INTO @nombrepro, @precio
WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'Nombre: ' + @nombrepro
	IF (@precio > 30) 
	PRINT 'Nombre: ' + @nombrepro+ 'Precio alto'
	ELSE 
	PRINT 'Nombre: ' + @nombrepro+ 'Precio bajo'
	FETCH cursor5 INTO @nombrepro, @precio
END
CLOSE cursor5

DECLARE @nombreprodu varchar (20)
DECLARE @preciop int
DECLARE cursor6 CURSOR FOR 
SELECT Nombre, Precio from Producto
OPEN cursor6
FETCH cursor6 INTO @nombrepro, @preciop
WHILE (@@FETCH_STATUS = 0)
BEGIN
	IF (@preciop > (SELECT AVG(Precio) AS MediaPrecio FROM Producto)) 
	PRINT 'Nombre: ' + @nombreprodu+ 'Precio alto a la media'
	ELSE 
	PRINT 'Nombre: ' + @nombreprodu+ 'Precio bajo a la media'	
	FETCH cursor6 INTO @nombreprodu, @preciop
END
CLOSE cursor6

DECLARE @nombreproduc varchar (20)
DECLARE @preciopr int
DECLARE cursor7 CURSOR FOR 
SELECT Nombre, Precio FROM Producto
FOR UPDATE
OPEN cursor7
FETCH cursor7 INTO @nombreproduc, @preciopr
WHILE (@@FETCH_STATUS = 0)
BEGIN
	IF (@preciopr >= 100) 
	SET @preciopr=@preciopr*0.5
	ELSE 
	SET @preciopr=@preciopr*0.2
	UPDATE Producto  SET Precio = @preciopr  WHERE CURRENT OF CPRODUCTO
	PRINT 'EL PRECIO DEL PRODUCTO '+ @nombreproduc+ ' ES ' + STR(@preciopr)
	FETCH cursor7 INTO @nombreproduc, @preciopr
END
CLOSE cursor7

DECLARE @nombreclie varchar (20)
DECLARE @unidadesc TinyInt
DECLARE cursor8 CURSOR FOR
SELECT Cliente.Nombre, Compras.Unidades from Cliente
JOIN Compras ON Cliente.DNI = Compras.DNI_Cliente
OPEN cursor8
FETCH cursor8 INTO @nombreclie
WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'Nombre: ' + @nombreclie + 'Unidades: ' +@unidadesc+ 
	'Suma Total: ' +(SELECT SUM(Unidades) AS SumaUnidades FROM Producto)
	FETCH cursor8 INTO @nombreclie, @unidadesc
END
CLOSE cursor8
DEALLOCATE cursor8

DECLARE @nombreclien varchar (20)
DECLARE @unidadesco TinyInt
DECLARE @fechacomprac Datetime
DECLARE cursor9 CURSOR FOR
SELECT Cliente.Nombre, Compras.Unidades, Compras.FechaCompra from Cliente
JOIN Compras ON Cliente.DNI = Compras.DNI_Cliente
OPEN cursor9
FETCH cursor9 INTO @nombreclien, @unidadesco, @fechacomprac
WHILE (@@FETCH_STATUS = 0)
BEGIN
	PRINT 'Nombre: ' + @nombreclie + 'Unidades: ' +@unidadesc+ 
	'Suma Total: ' +(SELECT SUM(Unidades) AS SumaUnidades FROM Producto)+
	'Fecha: ' + CONVERT (varchar (10), @fechacomprac) 
	FETCH cursor9 INTO @nombreclien, @unidadesco, @fechacomprac
END
CLOSE cursor9
DEALLOCATE cursor9

DECLARE @nombreproduct varchar (20)
DECLARE @preciopro int
DECLARE cursor10 CURSOR FOR 
SELECT Nombre, Precio from Producto
OPEN cursor10
FETCH cursor10 INTO @nombreproduct, @preciopro
WHILE (@@FETCH_STATUS = 0)
BEGIN
	IF (@preciopro < 50) 
	PRINT 'Precio barato'
	IF (@preciopro > 50 AND @preciopro < 100) 
	PRINT 'Precio medio'
	IF (@preciopro > 100 AND @preciopro < 500) 
	PRINT 'Precio caro'
	ELSE 
	PRINT 'Precio muy caro'	
	FETCH cursor10 INTO @nombreproduct, @preciopro
END
CLOSE cursor10
DEALLOCATE cursor10