CREATE TABLE Cliente(
	DNI Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Apellidos Varchar(30) NOT NULL,
	Direccion Varchar(50) NULL,
	FechaNacimiento Date NULL,
	CONSTRAINT PK_Cliente_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Proveedor(
	CodProveedor Int IDENTITY(1,1) NOT NULL,
	CIF Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Direccion Varchar(50) NULL,
	CONSTRAINT PK_Proveedor_CodProveedor PRIMARY KEY(CodProveedor),
	CONSTRAINT UQ_Proveedor_Cif UNIQUE(CIF)
)
CREATE TABLE Producto(
	CodProducto Int IDENTITY(1,1) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Codigo Varchar(10) NOT NULL,
	Precio Float NOT NULL,
	Descripcion Varchar(500) NULL,
	CodProveedor Int NOT NULL,
	CONSTRAINT PK_Producto_CodProducto PRIMARY KEY(CodProducto),
	CONSTRAINT FK_Producto_CodProveedor FOREIGN KEY(CodProveedor)
	REFERENCES Proveedor(CodProveedor),
	CONSTRAINT UQ_Producto_Codigo UNIQUE(Codigo)
)
CREATE TABLE Compras(
	DNI_Cliente Varchar(9) NOT NULL,
	CodProducto Int NOT NULL,
	FechaCompra Datetime NOT NULL,
	Unidades TinyInt NOT NULL,
	CONSTRAINT PK_Compras_DNIProductoFecha PRIMARY KEY(DNI_Cliente,
	CodProducto,FechaCompra),
	CONSTRAINT FK_Compras_DNI FOREIGN KEY(DNI_Cliente)
	REFERENCES Cliente(DNI),
	CONSTRAINT FK_Compras_CodProducto FOREIGN KEY(CodProducto)
	REFERENCES Producto(CodProducto),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades > 0 AND Unidades < 100)
)

INSERT�INTO�Cliente�(DNI, Nombre, Apellidos, Direccion, FechaNacimiento)
VALUES�('46852869Y', 'Cliente 1', 'L�pez', 'C\Nueva 1', '2000-5-14'),
('3459596N', 'Cliente 2', 'Pablo', 'C\Nueva 5', '2001-5-27')

INSERT�INTO�Compras (DNI_Cliente, FechaCompra, Unidades)
VALUES�('3459596M', '2015-5-14', 2),
('3459596N', '2015-5-27', 3)

INSERT�INTO�Producto (Nombre, Codigo, Precio, Descripcion)
VALUES�('Producto 1', '3459596MN', 14, 'Producto 1 Descripcion'),
('Producto 2', '3459596MC', 27, 'Producto 3 Descripcion')

INSERT�INTO�Proveedor(CIF, Nombre, Direccion)
VALUES�('3459596T', 'Proveedor 1', 'C\Nueva 1'),
('3459596O', 'Proveedor 2','C\Nueva 5')

CREATE TRIGGER TRIGGER_1
ON Cliente
FOR INSERT
AS
IF EXISTS (SELECT SUBSTRING(DNI, 1, 8), SUBSTRING(Nombre, 1, 8), SUBSTRING(Apellidos, 1, 8),
SUBSTRING(Direccion, 1, 8), SUBSTRING(FechaNacimiento, 1, 8) FROM Cliente)
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO

CREATE TRIGGER TRIGGER_2
ON Cliente
FOR UPDATE
AS
IF UPDATE (FechaNacimiento)
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO
UPDATE Cliente SET FechaNacimiento='2020-05-24'
GO

CREATE TRIGGER TRIGGER_3
ON Cliente
FOR DELETE
AS
IF EXISTS (SELECT DNI FROM Cliente INNER JOIN Compras ON Compras.DNI_Cliente = Cliente.Dni WHERE Dni = DNI_Cliente)
BEGIN
	DELETE Compras FROM Compras INNER JOIN Cliente ON Compras.DNI_Cliente = Cliente.Dni WHERE Dni = DNI_Cliente 
END

CREATE TRIGGER TRIGGER_4
ON Producto
FOR INSERT
AS
IF EXISTS (SELECT CodProveedor FROM Producto WHERE CodProveedor>0)
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO

CREATE TRIGGER TRIGGER_5
ON Producto
FOR UPDATE
AS
IF UPDATE (Descripcion)
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO
UPDATE Producto SET Descripcion=0 WHERE Descripcion IS NULL
ALTER TABLE Producto ALTER COLUMN Descripcion INTEGER NOT NULL
GO

CREATE TRIGGER TRIGGER_6
ON Compras
FOR DELETE
AS
IF EXISTS (SELECT FechaCompra, Unidades FROM Compras
WHERE CodProducto = (SELECT CodProducto FROM DELETED) )
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO

CREATE TRIGGER TRIGGER_7
ON Proveedor
FOR INSERT
AS
IF (SELECT CIF FROM INSERTED) IS NULL OR
(SELECT Nombre FROM INSERTED) = NULL
BEGIN
	PRINT 'El CIF y el Nombre no pueden ser NULL'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Compra introducida correctamente'
GO

INSERT INTO Proveedor(CodProveedor, CIF, Nombre, Direccion)
VALUES('10', NULL, NULL, 'Calle Sanjuan')

CREATE TRIGGER TRIGGER_8
ON Cliente
FOR UPDATE
AS
IF UPDATE (Proveedor)
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO
UPDATE Proveedor SET LEN(Direccion) WHERE Direccion=10

CREATE TRIGGER TRIGGER_9
ON Producto
FOR DELETE
AS
IF EXISTS (SELECT Nombre, Codigo, Precio, Descripcion FROM Producto
WHERE CodProveedor = (SELECT CodProveedor FROM DELETED) )
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO

CREATE TRIGGER TRIGGER_10
ON Compras
FOR INSERT
AS
IF EXISTS (SELECT Unidades FROM Compras WHERE Unidades>0)
BEGIN
	PRINT 'Cancelado'
	ROLLBACK TRANSACTION
END
ELSE 
	PRINT 'Correctamente'
GO