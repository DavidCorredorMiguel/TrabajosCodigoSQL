CREATE TABLE Cliente(
	DNI Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Apellidos Varchar(30) NOT NULL,
	Direccion Varchar(50) NULL,
	FechaNacimiento Date NULL,
	CONSTRAINT PK_Cliente_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Proveedor(
	CodProveedor Int IDENTITY(1,1) NOT NULL,
	CIF Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Direccion Varchar(50) NULL,
	CONSTRAINT PK_Proveedor_CodProveedor PRIMARY KEY(CodProveedor),
	CONSTRAINT UQ_Proveedor_Cif UNIQUE(CIF)
)
CREATE TABLE Producto(
	CodProducto Int IDENTITY(1,1) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Codigo Varchar(10) NOT NULL,
	Precio Float NOT NULL,
	Descripcion Varchar(500) NULL,
	CodProveedor Int NOT NULL,
	CONSTRAINT PK_Producto_CodProducto PRIMARY KEY(CodProducto),
	CONSTRAINT FK_Producto_CodProveedor FOREIGN KEY(CodProveedor)
	REFERENCES Proveedor(CodProveedor),
	CONSTRAINT UQ_Producto_Codigo UNIQUE(Codigo)
)
CREATE TABLE Compras(
	DNI_Cliente Varchar(9) NOT NULL,
	CodProducto Int NOT NULL,
	FechaCompra Datetime NOT NULL,
	Unidades TinyInt NOT NULL,
	CONSTRAINT PK_Compras_DNIProductoFecha PRIMARY KEY(DNI_Cliente,
	CodProducto,FechaCompra),
	CONSTRAINT FK_Compras_DNI FOREIGN KEY(DNI_Cliente)
	REFERENCES Cliente(DNI),
	CONSTRAINT FK_Compras_CodProducto FOREIGN KEY(CodProducto)
	REFERENCES Producto(CodProducto),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades BETWEEN 0 AND 100),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades > 0 AND Unidades < 100)
)

INSERT�INTO�Cliente�(DNI, Nombre, Apellidos, Direccion, FechaNacimiento)
VALUES�('3459596M', 'Cliente 1', 'L�pez', 'C\Nueva 1', '2000-5-14'),
('3459596N', 'Cliente 2', 'Pablo', 'C\Nueva 5', '2001-5-27')

INSERT�INTO�Compras (DNI_Cliente, FechaCompra, Unidades)
VALUES�('3459596M', '2015-5-14', 2),
('3459596N', '2015-5-27', 3)

INSERT�INTO�Producto (Nombre, Codigo, Precio, Descripcion)
VALUES�('Producto 1', '3459596MN', 14, 'Producto 1 Descripcion'),
('Producto 2', '3459596MC', 27, 'Producto 3 Descripcion')

INSERT�INTO�Proveedor(CIF, Nombre, Direccion)
VALUES�('3459596T', 'Proveedor 1', 'C\Nueva 1'),
('3459596O', 'Proveedor 2','C\Nueva 5')

PRINT 'Hola Mundo';
GO

DECLARE @numero int
SELECT @numero WHERE @numero >  10;
PRINT '' + STR(@numero);
GO

DECLARE @numeropide int
PRINT '' + STR(@numeropide);
GO

DECLARE @nume int
SET @nume = 0
WHILE (@nume < 100)
BEGIN
	SET @nume = @nume + 1
	PRINT cast(@nume AS varchar)
END

SELECT Cliente.Nombre FROM Cliente
WHERE Cliente.DNI = ''
PRINT 'Introduce DNI: ' + STR(Cliente.DNI);
GO 

SELECT Producto.Precio, Producto.Descripcion FROM Producto
WHERE Producto.CodProducto = ''
PRINT 'Introduce CodProducto: ' + STR(Producto.CodProducto);
GO 

SELECT Cliente.Nombre, Cliente.Apellidos, Cliente.Direccion, Cliente.FechaNacimiento FROM Cliente
WHERE Cliente.DNI = ''
PRINT 'Introduce DNI: ' + STR(Cliente.DNI);
GO 

SELECT Compras.Unidades FROM Compras INNER JOIN Producto ON Compras.CodProducto = Producto.CodProducto
WHERE Producto.CodProducto = ''
PRINT 'Introduce CodProducto: ' + STR(Producto.CodProducto);
GO 

SELECT Compras.Unidades FROM Compras INNER JOIN Producto ON Compras.CodProducto = Producto.CodProducto
WHERE Producto.CodProducto = ''
PRINT 'Introduce CodProducto: ' + STR(Producto.CodProducto);
IF Unidades>30
	PRINT 'Quedan pocas unidades'
GO 

SELECT Producto.CodProducto FROM Producto
WHERE Producto.CodProducto <=  50;
PRINT '' + STR(Producto.CodProducto);
GO 