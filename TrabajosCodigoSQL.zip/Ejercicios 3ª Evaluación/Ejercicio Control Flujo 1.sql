CREATE TABLE Cliente(
	DNI Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Apellidos Varchar(30) NOT NULL,
	Direccion Varchar(50) NULL,
	FechaNacimiento Date NULL,
	CONSTRAINT PK_Cliente_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Proveedor(
	CodProveedor Int IDENTITY(1,1) NOT NULL,
	CIF Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Direccion Varchar(50) NULL,
	CONSTRAINT PK_Proveedor_CodProveedor PRIMARY KEY(CodProveedor),
	CONSTRAINT UQ_Proveedor_Cif UNIQUE(CIF)
)
CREATE TABLE Producto(
	CodProducto Int IDENTITY(1,1) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Codigo Varchar(10) NOT NULL,
	Precio Float NOT NULL,
	Descripcion Varchar(500) NULL,
	CodProveedor Int NOT NULL,
	CONSTRAINT PK_Producto_CodProducto PRIMARY KEY(CodProducto),
	CONSTRAINT FK_Producto_CodProveedor FOREIGN KEY(CodProveedor)
	REFERENCES Proveedor(CodProveedor),
	CONSTRAINT UQ_Producto_Codigo UNIQUE(Codigo)
)
CREATE TABLE Compras(
	DNI_Cliente Varchar(9) NOT NULL,
	CodProducto Int NOT NULL,
	FechaCompra Datetime NOT NULL,
	Unidades TinyInt NOT NULL,
	CONSTRAINT PK_Compras_DNIProductoFecha PRIMARY KEY(DNI_Cliente,
	CodProducto,FechaCompra),
	CONSTRAINT FK_Compras_DNI FOREIGN KEY(DNI_Cliente)
	REFERENCES Cliente(DNI),
	CONSTRAINT FK_Compras_CodProducto FOREIGN KEY(CodProducto)
	REFERENCES Producto(CodProducto),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades > 0 AND Unidades < 100)
)

INSERT�INTO�Cliente�(DNI, Nombre, Apellidos, Direccion, FechaNacimiento)
VALUES�('46852869Y', 'Cliente 1', 'L�pez', 'C\Nueva 1', '2000-5-14'),
('3459596N', 'Cliente 2', 'Pablo', 'C\Nueva 5', '2001-5-27')

INSERT�INTO�Compras (DNI_Cliente, FechaCompra, Unidades)
VALUES�('3459596M', '2015-5-14', 2),
('3459596N', '2015-5-27', 3)

INSERT�INTO�Producto (Nombre, Codigo, Precio, Descripcion)
VALUES�('Producto 1', '3459596MN', 14, 'Producto 1 Descripcion'),
('Producto 2', '3459596MC', 27, 'Producto 3 Descripcion')

INSERT�INTO�Proveedor(CIF, Nombre, Direccion)
VALUES�('3459596T', 'Proveedor 1', 'C\Nueva 1'),
('3459596O', 'Proveedor 2','C\Nueva 5')

PRINT 'Hola Mundo';

DECLARE @NUM2 TINYINT
	SET @NUM2 = 11
	IF (@NUM2 > 10)
		PRINT 'EL NUMERO ES MAYOR DE 10'
	ELSE 
	PRINT 'EL NUMERO ES MENOR O IGUAL A 10'

DECLARE @numero3 INT;
SET @numero3 = 15;
PRINT @numero3;

DECLARE @nume int
SET @nume = 0
WHILE (@nume < 100)
BEGIN
	SET @nume = @nume + 1
	PRINT cast (@nume AS varchar)
END

DECLARE @dnicliente varchar (9)
DECLARE @nombre varchar (20)
SET @dnicliente='46852869Y'
SET @nombre= (SELECT Nombre
FROM Cliente
WHERE DNI=@dnicliente)
PRINT 'El nombre es: ' + @nombre

DECLARE @CodProducto int
DECLARE @precio float
DECLARE @descripcion varchar (500)
SET @CodProducto=2
SELECT @precio=Precio, @descripcion=Descripcion
FROM Producto
WHERE CodProducto=@CodProducto
PRINT 'El precio es: ' + CONVERT (varchar (10), @precio) + ' ' + 'La descripci�n es: ' + @descripcion

DECLARE @nombres varchar (20)
DECLARE @apellidos varchar (30)
DECLARE @direccion varchar (50)
DECLARE @FechaNacimiento date
DECLARE @DNI varchar (9)
SET @DNI='46852869Y'
SELECT @nombres=Nombre, @apellidos=Apellidos, @direccion=Direccion, @FechaNacimiento=FechaNacimiento
FROM Cliente
WHERE DNI=@DNI
PRINT 'Los valores del cliente son: Nombre: '+ @nombres + 'Los apellidos son: '+ @apellidos 
+ ' La direcci�n es: ' + @direccion + ' La fecha de nacimiento es: ' + CONVERT (varchar (10), @FechaNacimiento)

DECLARE @nombresc varchar (20)
DECLARE @unidades tinyint
SET @nombresc='Monitor'
SELECT @unidades=SUM(Unidades) FROM Compras
INNER JOIN Producto ON Producto.CodProducto = Compras.CodProducto
WHERE Nombre=@nombresc
PRINT 'Hemos vendido: ' + CONVERT (varchar (10), @unidades) + ' unidades'

DECLARE @TOTAL varchar (20)
DECLARE @NOMBRECO VARCHAR (20)
SET @NOMBRECO = 'Pan'
SET @TOTAL= (SELECT SUM(Unidades) from Compras INNER JOIN
Producto ON Compras.CodProducto = Producto.CodProducto
WHERE Nombre = @NOMBRECO)
IF (@TOTAL > 30) 
PRINT 'Quedan pocas Unidades Se vendieron: ' + @TOTAL + ' Unidades de ' + @NOMBRECO
ELSE 
PRINT 'A�n quedan unidades'

DECLARE @contador int=1;
WHILE @contador < 50
BEGIN
SELECT top (1) codProducto, nombre
FROM producto
WHERE codProducto = @contador
PRINT STR(@codProducto) + @nombre
SET @contador += 1;
END;
