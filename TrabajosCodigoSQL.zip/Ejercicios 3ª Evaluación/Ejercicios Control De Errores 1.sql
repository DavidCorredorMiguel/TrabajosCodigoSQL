CREATE TABLE Cliente(
	DNI Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Apellidos Varchar(30) NOT NULL,
	Direccion Varchar(50) NULL,
	FechaNacimiento Date NULL,
	CONSTRAINT PK_Cliente_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Proveedor(
	CodProveedor Int IDENTITY(1,1) NOT NULL,
	CIF Varchar(9) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Direccion Varchar(50) NULL,
	CONSTRAINT PK_Proveedor_CodProveedor PRIMARY KEY(CodProveedor),
	CONSTRAINT UQ_Proveedor_Cif UNIQUE(CIF)
)
CREATE TABLE Producto(
	CodProducto Int IDENTITY(1,1) NOT NULL,
	Nombre Varchar(20) NOT NULL,
	Codigo Varchar(10) NOT NULL,
	Precio Float NOT NULL,
	Descripcion Varchar(500) NULL,
	CodProveedor Int NOT NULL,
	CONSTRAINT PK_Producto_CodProducto PRIMARY KEY(CodProducto),
	CONSTRAINT FK_Producto_CodProveedor FOREIGN KEY(CodProveedor)
	REFERENCES Proveedor(CodProveedor),
	CONSTRAINT UQ_Producto_Codigo UNIQUE(Codigo)
)
CREATE TABLE Compras(
	DNI_Cliente Varchar(9) NOT NULL,
	CodProducto Int NOT NULL,
	FechaCompra Datetime NOT NULL,
	Unidades TinyInt NOT NULL,
	CONSTRAINT PK_Compras_DNIProductoFecha PRIMARY KEY(DNI_Cliente,
	CodProducto,FechaCompra),
	CONSTRAINT FK_Compras_DNI FOREIGN KEY(DNI_Cliente)
	REFERENCES Cliente(DNI),
	CONSTRAINT FK_Compras_CodProducto FOREIGN KEY(CodProducto)
	REFERENCES Producto(CodProducto),
	CONSTRAINT CK_Compras_Unidades CHECK(Unidades > 0 AND Unidades < 100)
)

INSERT�INTO�Cliente�(DNI, Nombre, Apellidos, Direccion, FechaNacimiento)
VALUES�('46852869Y', 'Cliente 1', 'L�pez', 'C\Nueva 1', '2000-5-14'),
('3459596N', 'Cliente 2', 'Pablo', 'C\Nueva 5', '2001-5-27')

INSERT�INTO�Compras (DNI_Cliente, FechaCompra, Unidades)
VALUES�('3459596M', '2015-5-14', 2),
('3459596N', '2015-5-27', 3)

INSERT�INTO�Producto (Nombre, Codigo, Precio, Descripcion)
VALUES�('Producto 1', '3459596MN', 14, 'Producto 1 Descripcion'),
('Producto 2', '3459596MC', 27, 'Producto 3 Descripcion')

INSERT�INTO�Proveedor(CIF, Nombre, Direccion)
VALUES�('3459596T', 'Proveedor 1', 'C\Nueva 1'),
('3459596O', 'Proveedor 2','C\Nueva 5')

BEGIN TRY
	DECLARE @DIVISOR INT, @DIVIDENDO INT, @RESULTADO INT
	SET @DIVIDENDO = 100
	SET @DIVISOR = 20  
	SET @RESULTADO = @DIVIDENDO/@DIVISOR
	PRINT 'NO HAY ERROR'
END TRY
BEGIN CATCH
	PRINT '0'
	PRINT ERROR_MESSAGE()
	PRINT ERROR_STATE()
END CATCH; 

BEGIN TRY
	DELETE from Cliente Where DNI='46852869Y'
	PRINT 'NO HAY ERROR'
END TRY
BEGIN CATCH
	PRINT 'HAY ERROR'
	PRINT ERROR_MESSAGE()
	PRINT ERROR_STATE()
END CATCH;

BEGIN TRY
	DELETE FROM Cliente Where DNI = '46852869Y'
	PRINT 'NO HAY ERROR'
END TRY
BEGIN CATCH
	IF @@ERROR=547
	PRINT 'NO SE PUEDE ELIMINAR A ESTE CLIENTE'
	PRINT ERROR_MESSAGE()
	PRINT ERROR_STATE()
END CATCH; 

BEGIN TRY
	DECLARE @num INT = 0;
	WHILE @num>=0 AND @num<=20
	PRINT 'NO HAY ERROR'
END TRY
BEGIN CATCH
	IF (@num = 10)
	BEGIN
		RAISERROR ('Ha llegado al limite', 15, 1)
	END
	PRINT ERROR_MESSAGE()
	PRINT ERROR_STATE()
END CATCH; 