CREATE TABLE Empleados(
DNI Varchar(8) NOT NULL,
Nombre Varchar(10) NOT NULL,
Apellido1 Varchar(15) NOT NULL,
Apellido2 Varchar(15) NULL,
Direcc1 Varchar(25) NULL,
Direcc2 Varchar(20) NULL,
Ciudad Varchar(20) NULL,
Provincia Varchar(20) NULL,
Cod_Postal Varchar(5) NULL,
Sexo Char(1) NULL,
Fecha_Nac Date NULL,
CONSTRAINT CK_Empleados_Sexo CHECK(Sexo IN('H','M')),
CONSTRAINT PK_Empleados_DNI PRIMARY KEY(DNI)
)
CREATE TABLE Departamentos(
DPTO_Cod Smallint NOT NULL IDENTITY(1,1),
Nombre_DPTO Varchar(30) NOT NULL,
DPTO_Padre Smallint NULL,
Presupuesto Float NOT NULL,
Pres_Actual Float NULL,
CONSTRAINT UN_Departamentos_Nombre UNIQUE(Nombre_DPTO),
CONSTRAINT PK_Departamentos_CodDep PRIMARY KEY(DPTO_Cod)
)
CREATE TABLE Trabajos(
Trabajo_Cod Smallint NOT NULL IDENTITY(1,1),
Nombre_Trab Varchar(20) NOT NULL,
Salario_Min Float NOT NULL,
Salario_Max Float NOT NULL,
CONSTRAINT UN_Trabajos_Nombre UNIQUE(Nombre_Trab),
CONSTRAINT PK_Trabajos_CodTra PRIMARY KEY(Trabajo_Cod)
)
CREATE TABLE Historial_Laboral(
Empleado_DNI Varchar(8) NOT NULL,
Trabajo_Cod Smallint NOT NULL,
Fecha_Inicio Date NOT NULL,
Fecha_Fin Date NULL,
DPTO_Cod Smallint NULL,
Supervisor_DNI Varchar(8) NULL,
CONSTRAINT PK_HLaboral_EmpTraFec PRIMARY KEY
(Empleado_DNI,Trabajo_Cod,Fecha_Inicio),
CONSTRAINT FK_HLaboral_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI),
CONSTRAINT FK_HLaboral_CodTrab FOREIGN KEY(Trabajo_Cod)
REFERENCES Trabajos(Trabajo_Cod),
CONSTRAINT FK_HLaboral_DPTO FOREIGN KEY(DPTO_Cod)
REFERENCES Departamentos(DPTO_Cod),
CONSTRAINT FK_HLaboral_Supervisor FOREIGN KEY(Supervisor_DNI)
REFERENCES Empleados(DNI)
)
CREATE TABLE Historial_Salarial(
Empleado_DNI Varchar(8) NOT NULL,
Salario Float NOT NULL,
Fecha_Comienzo Date NOT NULL,
Fecha_Fin Date NULL,
CONSTRAINT PK_HSalarial_EmpSalFec PRIMARY KEY
(Empleado_DNI,Salario,Fecha_Comienzo),
CONSTRAINT FK_HSalarial_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI)
)
CREATE TABLE Universidades(
Univ_Cod smallint NOT NULL IDENTITY(1,1),
Nombre_Univ Varchar(25) NOT NULL,
Ciudad Varchar(20) NULL,
Municipio Varchar(20) NULL,
Cod_Postal Varchar(5) NULL,
CONSTRAINT PK_Universidades_CodUni PRIMARY KEY(Univ_Cod)
)
CREATE TABLE Estudios(
Empleado_DNI Varchar(8) NOT NULL,
Universidad Smallint NULL,
A�o SmallInt NULL,
Grado Varchar(3) NULL,
Especialidad Varchar(20) NULL,
CONSTRAINT FK_Estudios_DNI FOREIGN KEY(Empleado_DNI)
REFERENCES Empleados(DNI),
CONSTRAINT FK_Estudios_CodUniversidad FOREIGN KEY (Universidad)
REFERENCES Universidades(Univ_Cod)
)
INSERT�INTO�empleados�( nombre,�apellido1,�apellido2,�dni,�sexo�)
VALUES�('Sergio',�'Palma',�'Entrena',�'111222',�'H')
INSERT�INTO�empleados�( nombre,�apellido1,�apellido2,�dni,�sexo)
VALUES�('Lucia',�'Ortega',�'Plus',�'222333',�NULL)�;
INSERT�INTO�historial_laboral�( empleado_dni, Trabajo_Cod, fecha_inicio, fecha_fin,
dpto_cod, supervisor_dni�)
VALUES�('111222', 1, '2010-01-01', NULL, NULL, '222333') ;

CREATE FUNCTION Funcion1(@nombre varchar, @apellido1 varchar, @apellido2 varchar) RETURNS varchar(9)
AS
	BEGIN
	DECLARE @dni varchar(9)
	SELECT @dni = (SELECT top 1 DNI from Empleados WHERE Nombre = @nombre
	AND Apellido1 = @apellido1 AND Apellido2 = @apellido2)
	RETURN @dni
END
GO 

SELECT dbo.Funcion1('Sergio', 'Palma', 'Entrena')

CREATE FUNCTION Funcion2(@dni2 varchar) RETURNS varchar
AS
	BEGIN
	SELECT @dni2 = (SELECT Nombre,Apellido1,Apellido2 from Empleados WHERE DNI=@dni2)
	RETURN @dni2
END
GO 

SELECT dbo.Funcion2('111222')

CREATE FUNCTION Funcion3(@dni3 varchar) RETURNS varchar
AS
	BEGIN
	DECLARE @dni varchar(9)
	SELECT @dni3 = (SELECT Trabajo_Cod,Fecha_Inicio,Fecha_Fin,DPTO_Cod,Supervisor_DNI 
	from Historial_Laboral INNER JOIN Empleados ON Historial_Laboral.Empleado_DNI=Empleados.DNI WHERE DNI=@dni3)
	RETURN @dni3
END
GO 

SELECT dbo.Funcion3('111222')

CREATE FUNCTION Funcion4(@dni4 varchar) RETURNS varchar
AS
	BEGIN
	SELECT @dni4 = (SELECT Historial_Salarial.Salario,Historial_Salarial.Fecha_Fin
	from Historial_Salarial INNER JOIN Empleados ON Historial_Salarial.Empleado_DNI=Empleados.DNI WHERE DNI=@dni4)
	RETURN @dni4
END
GO 

SELECT dbo.Funcion4('111222')

CREATE FUNCTION Funcion5(@dni5 varchar, @salario int) RETURNS varchar
AS
	BEGIN
	DECLARE cursor5 CURSOR FOR 
	SELECT @dni5 = (SELECT Historial_Salarial.Salario,Historial_Salarial.Fecha_Fin
	from Historial_Salarial INNER JOIN Empleados ON Historial_Salarial.Empleado_DNI=Empleados.DNI WHERE DNI=@dni5 AND Salario=@salario)
	OPEN cursor5
	FETCH cursor5 INTO @salario
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@salario > 0 AND @salario <= 800) 
		PRINT 'Precio bajo'
		ELSE IF (@salario >= 801 AND @salario <= 1500) 
		PRINT 'Precio medio'
		IF (@salario >= 1501) 
		PRINT 'Precio alto'
		FETCH cursor5 INTO @salario
	END
	CLOSE cursor5
	RETURN @dni5
END
GO 

PRINT Funcion5('111222')

CREATE FUNCTION Funcion6(@total int) RETURNS varchar
AS
	BEGIN
	SELECT @total = (SELECT sum(DPTO_Cod) as Totaldepartamento from Departamentos)
	RETURN @total
END
GO 

SELECT dbo.Funcion6('')

CREATE FUNCTION Funcion7(@total2 int) RETURNS varchar
AS
	BEGIN
	DECLARE cursor7 CURSOR FOR 
	SELECT @total2 = (SELECT sum(DPTO_Cod) as Totaldepartamento, Nombre_DPTO from Departamentos)
	OPEN cursor7
	FETCH cursor7 INTO @total2
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@total2 < 5) 
		PRINT 'Departamento peque�o'
		ELSE IF (@total2 >= 5 AND @total2 <= 10) 
		PRINT 'Departamento mediano'
		IF (@total2 > 10) 
		PRINT 'Departamento grande'
		FETCH cursor5 INTO @salario
	END
	CLOSE cursor5
	RETURN @total2
END
GO 

SELECT dbo.Funcion7('')

CREATE FUNCTION Funcion8(@fechanac int) RETURNS varchar
AS
	BEGIN
	SELECT @fechanac = (SELECT DATEDIFF(YEAR,Fecha_Nac,GETDATE()) As Diferenciaa�os from Empleados)
	RETURN @fechanac
END
GO 

SELECT dbo.Funcion8('')

CREATE FUNCTION Funcion9(@fechainicio varchar) RETURNS varchar
AS
	BEGIN
	SELECT @fechainicio = (SELECT Trabajo_Cod,Fecha_Inicio,Fecha_Fin,DPTO_Cod,Supervisor_DNI 
	from Historial_Laboral WHERE Fecha_Inicio=@fechainicio)
	RETURN @fechainicio
END
GO 

SELECT dbo.Funcion9('2010-01-01')

CREATE FUNCTION Funcion10(@especial varchar) RETURNS varchar
AS
	BEGIN
	SELECT @especial = (SELECT Universidades.Nombre_Univ, Universidades.Municipio,
	Universidades.Ciudad, Universidades.Cod_Postal, Estudios.Especialidad
	from Universidades INNER JOIN Estudios ON Universidades.Univ_Cod=Estudios.Universidad
	WHERE Especialidad=@especial)
	RETURN @especial
END
GO 

SELECT dbo.Funcion10('')